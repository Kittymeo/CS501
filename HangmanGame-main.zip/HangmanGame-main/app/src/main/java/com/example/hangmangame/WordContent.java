package com.example.hangmangame;

public class WordContent {

    public static String[][] words = {{"banana","Fruit"},{"apple","Fruit"},
            {"mango","Fruit"},{"pear","Fruit"},{"peach","Fruit"},{"orange","Fruit"},{"hoodie","Clothes"},{"dress","Clothes"}
            ,{"coat","Clothes"},{"black","Color"},{"yellow","Color"},{"gucci","Luxury"},{"dior","Luxury"},{"soccer","Sports"}
            ,{"tennis","Sports"},{"hermes","Luxury"},{"lion","Animal"},{"puma","Animal"},{"panda","Animal"},{"horse","Animal"}
            ,{"snake","Animal"},{"whale","Animal"},{"prada","Luxury"},{"kenzo","Luxury"}


    };


}
